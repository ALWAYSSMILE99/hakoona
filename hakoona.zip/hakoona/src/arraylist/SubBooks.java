package arraylist;
import java.util.*;  
class SubBook {  
int id;  
String name,author,publisher;  
int quantity;  
public SubBook(int id, String name, String author, String publisher, int quantity) {  
    this.id = id;  
    this.name = name;  
    this.author = author;  
    this.publisher = publisher;  
    this.quantity = quantity;  
}  
}  
public class SubBooks{  
public static void main(String[] args) {  
    //Creating list of Books  
    List<SubBook> list=new ArrayList<SubBook>();  
    //Creating Books  
    SubBook b1=new SubBook(101,"Let us C","Yashwant Kanetkar","BPB",8);  
    SubBook b2=new SubBook(102,"Data Communications & Networking","Forouzan","Mc Graw Hill",4);  
    SubBook b3=new SubBook(103,"Operating System","Galvin","Wiley",6);  
    //Adding Books to list  
    list.add(b1);  
    list.add(b2);  
    list.add(b3);  
    //Traversing list  
    for(SubBook b:list){  
        System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);  
    }  
}  
}  